# Versões do site do Faultline

Cada arquivo é o site completo daquela versão. Basta abrir no navegador.

| Arquivo | Data | O que mudou |
| --- | --- | --- |
| `faultline-v2.html` | 18/10/2026 | Base anterior ao motor de cenários: carrossel de sprites, tema claro e escuro, abas, cenários simples e imagens do chefe e dos fundos. |
| `faultline-v3.html` | 24/10/2026 | Ícone do GitHub no botão do topo; cenários com motor de câmera, chão e rota usando os sprites reais do jogo. |
| `faultline-v4.html` | 24/10/2026 | Quarto como Fase 1; caminhada mais lenta; pulo só na Empresa; robô andando. |
| `faultline-v5.html` | 24/10/2026 | Setas do carrossel consertadas; quarto parado; robô andando e atacando; Laboratório e Núcleo sem jogador. |
| `faultline-v6.html` | 30/10/2026 | Seção "Acesse o projeto" (código, sprites e download do jogo). |
| `faultline-v7.html` | 30/10/2026 | Seção "Criadores" com o papel de cada pessoa. |
| `faultline-v8.html` | 30/10/2026 | Seções em faixas de cartões com setas e círculos; cartão de documentação. **Versão atual.** |
